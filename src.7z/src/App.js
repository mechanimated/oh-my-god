import logo from './logo.svg';
import './App.css';
import NokemonContainer from './NokemonContainer';

function App() {
  return (
    <div className="ui raised segment">
      <NokemonContainer />
    </div>
  );
}

export default App;
