import React from "react";

function Battle({savedContacts, enemyContacts}) {


  
}

export default Battle;
